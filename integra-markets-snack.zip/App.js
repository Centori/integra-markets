// Import the main app
import App from './app/App';

// Export as the default export for Expo to register
export default App;
