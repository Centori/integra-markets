export default {
  background: '#121212',
  card: '#1E1E1E',
  text: '#ECECEC',
  textSecondary: '#A0A0A0',
  tint: '#4ECCA3',
  tintLight: 'rgba(78, 204, 163, 0.1)',
  border: '#333333',
  bullish: '#4ECCA3',
  bearish: '#F05454',
  neutral: '#EAB308',
};