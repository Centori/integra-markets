def main():
    print("Hello from integra!")


if __name__ == "__main__":
    main()
